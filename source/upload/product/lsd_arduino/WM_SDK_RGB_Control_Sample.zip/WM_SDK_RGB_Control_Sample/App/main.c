/***************************************************************************** 
* 
* File Name : main.c
* 
* Description: main 
* 
* Copyright (c) 2014 Winner Micro Electronic Design Co., Ltd. 
* All rights reserved. 
* 
* Author : dave
* 
* Date : 2014-6-14
*****************************************************************************/ 
#include "wm_include.h"
#include <string.h>
#include "wm_pwm.h"
#include "wm_cpu.h"
#include "wm_io.h"
#include "wm_demo.h"
#include "wm_regs.h"
#include "wm_dma.h"
#include "random.h"
#include "wm_gpio_afsel.h"


#define TASK_SIZE  256
#define STEP_SIZE  1

static OS_STK TaskStk[TASK_SIZE]; 

/* 
    ����GPIO�ĸ��ù��ܣ�ʹ�临��ΪPWM���ܣ�
*/
static int pwm_demo_multiplex_config(u8 channel)
{
	switch (channel)
	{
		case 0:
			wm_pwm1_config(WM_IO_PB_18);
		case 1:
			wm_pwm2_config(WM_IO_PB_17);
		case 2:
			wm_pwm3_config(WM_IO_PB_16);
		case 3:
			wm_pwm4_config(WM_IO_PB_15);
		case 4:
			wm_pwm5_config(WM_IO_PB_14);
		default:
			return -1;
	}
}

/* 
    ����5·PWMΪͬ��ģʽ��ͨ��1��ͨ��4���������ͨ��0һ�£�
*/
static int pwm_demo_allsyc_mode(u8 channel,u32 freq, u8 duty, u8 num)
{
    pwm_init_param pwm_param;
    int ret=-1;
	tls_sys_clk sysclk;
	
	tls_sys_clk_get(&sysclk);

    memset(&pwm_param, 0, sizeof(pwm_init_param));
    pwm_param.period = 255;
    pwm_param.cnt_type = WM_PWM_CNT_TYPE_EDGE_ALIGN_OUT;
    pwm_param.loop_type = WM_PWM_LOOP_TYPE_LOOP;
    pwm_param.mode = WM_PWM_OUT_MODE_ALLSYC;
    pwm_param.inverse_en = DISABLE;
    pwm_param.pnum = num;
    pwm_param.pnum_int = DISABLE;
    pwm_param.duty = duty;
    pwm_param.channel = channel;
    pwm_param.clkdiv = sysclk.apbclk*UNIT_MHZ/256/freq;

    ret = tls_pwm_out_init(pwm_param);

    return ret;
}

/* 
    ����2·PWMΪͬ��ģʽ��ͨ��1���������ͨ��0һ�£� ͨ��3���������ͨ��2һ�£�
*/
static int pwm_demo_2syc_mode(u8 channel,u32 freq, u8 duty, u8 num)
{
    pwm_init_param pwm_param;
    int ret=-1;
	tls_sys_clk sysclk;
	
	tls_sys_clk_get(&sysclk);

    memset(&pwm_param, 0, sizeof(pwm_init_param));
    pwm_param.period = 255;
    pwm_param.cnt_type = WM_PWM_CNT_TYPE_EDGE_ALIGN_OUT;
    pwm_param.loop_type = WM_PWM_LOOP_TYPE_LOOP;
    pwm_param.mode = WM_PWM_OUT_MODE_2SYC;
    pwm_param.inverse_en = DISABLE;
    pwm_param.pnum = num;
    pwm_param.pnum_int = DISABLE;
    pwm_param.duty = duty;
    pwm_param.channel = channel;
    pwm_param.clkdiv = sysclk.apbclk*UNIT_MHZ/256/freq;

    ret = tls_pwm_out_init(pwm_param);

    return ret;
}

/* 
    ����2·PWMΪ����ģʽ��ͨ��1���������ͨ��0������ ͨ��3���������ͨ��2������
*/
static int pwm_demo_mc_mode(u8 channel,u32 freq, u8 duty, u8 num)
{
    pwm_init_param pwm_param;
    int ret=-1;
	tls_sys_clk sysclk;
	
	tls_sys_clk_get(&sysclk);

    memset(&pwm_param, 0, sizeof(pwm_init_param));
    pwm_param.period = 255;
    pwm_param.cnt_type = WM_PWM_CNT_TYPE_EDGE_ALIGN_OUT;
    pwm_param.loop_type = WM_PWM_LOOP_TYPE_LOOP;
    pwm_param.mode = WM_PWM_OUT_MODE_MC;
    pwm_param.inverse_en = DISABLE;
    pwm_param.pnum = num;
    pwm_param.pnum_int = DISABLE;
    pwm_param.duty = duty;
    pwm_param.channel = channel;
    pwm_param.clkdiv = sysclk.apbclk*UNIT_MHZ/256/freq;
    
    pwm_param.dten = ENABLE;
    pwm_param.dtclkdiv = 3;
    pwm_param.dtcnt = 255;

    ret = tls_pwm_out_init(pwm_param);

    return ret;
}

/* 
    ����PWMΪ�ƶ�ģʽ���˴���ǿ��������ߵ�ƽ��
*/
static int pwm_demo_break_mode(u8 channel,u32 freq, u8 duty)
{
    int ret=-1;
    
    ret = tls_pwm_brake_mode_config(channel, ENABLE, WM_PWM_BRAKE_OUT_HIGH);

    return ret;
}


/**
 * @brief          This function is used demonstrate pwm usage.
 *
 * @param[in]       channel    pwm channel, range from 0 to 4
 * @param[in]       freq       freq range from 3Hz~160kHz
 * @param[in]       duty       duty range from 0 to 255
 * @param[in]       mode       0:BRAKE, 1:ALLSYC, 2:2SYC, 3:MC, 4:INDPT
 * @param[in]       pnum       period num,range from 0 to 255
 *
 * @retval         WM_SUCCESS success
 * @retval         WM_FAILED  failed
 *
 * @note           For example, call this like this "pwm_demo(0,20,99,1,0);".
 */
int pwm_work(u8 channel, u16 freq, u8 duty, u8 mode, u8 num)
{
    int  ret=-1;

	//printf("\r\nchannel:%d, freq:%d, duty:%d, mode:%d, num:%d\r\n", channel, freq, duty, mode, num);
    if(channel < 5)
    {
        pwm_demo_multiplex_config(channel);
        tls_pwm_stop(channel);
    }
    else
    {
        return WM_FAILED;
    }
    
    switch (mode)
    {
        case WM_PWM_OUT_MODE_INDPT:
            /* �������ģʽ */
            ret = tls_pwm_init(channel, freq, duty, num);
            if(ret != WM_SUCCESS)
                return ret;
            tls_pwm_start(channel);
            break;
            
        case WM_PWM_OUT_MODE_ALLSYC:
            /* ȫͨ��ͬ��ģʽ��channel 1-channel4�����channel0һ��  */
            ret = pwm_demo_allsyc_mode(channel, freq, duty, num);
            if(ret != WM_SUCCESS)
                return ret;
            tls_pwm_start(channel);
            break;
            
        case WM_PWM_OUT_MODE_2SYC:
             /* ˫ͨ��ͬ��ģʽ  */
            ret = pwm_demo_2syc_mode(channel, freq, duty, num);
            if(ret != WM_SUCCESS)
                return ret;
            tls_pwm_start(channel);
            break;
            
        case WM_PWM_OUT_MODE_MC:
            /* ˫ͨ������ģʽ  */
            ret = pwm_demo_mc_mode(channel, freq, duty, num);
            if(ret != WM_SUCCESS)
                return ret;
            tls_pwm_start(channel);
            break;
            
        case WM_PWM_OUT_MODE_BRAKE:
            /* �ƶ�ģʽ  */
            ret = pwm_demo_break_mode(channel, freq, duty);
            if(ret != WM_SUCCESS)
                return ret;
            tls_pwm_start(channel);
            break;
            
        default:
            break;
    }
	return WM_SUCCESS;
}

static void pwm_task(void *sdata)
{
    unsigned char duty[3] = {0};
    
    while (1) 
    {
        //��ȡ����������ݣ�������·PWM��ռ�ձ�
        random_get_bytes(duty, 3);

        //channel 0 ���pwm����Ƶ��100Hz ռ�ձ�duty[0] �������ģʽ���Զ�װ��
        pwm_work(0, 100, duty[0], 4, 0); //blue led

        //channel 1 ���pwm����Ƶ��100Hz ռ�ձ�duty[1] �������ģʽ���Զ�װ��
        pwm_work(1, 100, duty[1], 4, 0); //green led

        //channel 2 ���pwm����Ƶ��100Hz ռ�ձ�duty[2] �������ģʽ���Զ�װ��
        pwm_work(2, 100, duty[2], 4, 0); //red led

        //0.5����ʱ
        tls_os_time_delay(HZ/2);
    }
}

void UserMain(void)
{
    printf("\n user task\n");

    tls_os_task_create(NULL, NULL,
                        pwm_task,
                        NULL,
                        (void *)TaskStk,
                        TASK_SIZE * sizeof(u32),
                        31,
                        0);
#if DEMO_CONSOLE
    CreateDemoTask();
#endif
//�û��Լ���task
}


